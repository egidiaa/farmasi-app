<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class PelangganController extends Controller
{
    public function index()
    {
        return view('users.pelanggan.pelanggan', [
            "title" => "Data Pelanggan",
            "users" => User::filters(request(['q']))->paginate(5)->withQueryString()
        ]);
    }

    public function show(User $user)
    {
        return view('users.pelanggan.show', [
            "title" => "Detail Data Pelanggan",
            "user" => $user
        ]);
    }
}
