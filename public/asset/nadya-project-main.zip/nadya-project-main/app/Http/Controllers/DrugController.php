<?php

namespace App\Http\Controllers;

use App\Models\Drug;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class DrugController extends Controller
{
    public function index()
    {
        return view('drugs.index', [
            "title" => "Data Produk Obat",
            "drugs" => Drug::filters(request(['q']))->paginate(5)->withQueryString()
        ]);
    }

    public function create()
    {
        return view('drugs.create', [
            "title" => "Tambah Data Produk Obat Baru",
        ]);
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'kode_obat' => "required|min:5|max:5|unique:drugs",
            'nama_obat' => "required",
            'stock' => 'required|min:0|numeric',
            'harga_beli' => "required|min:0|numeric",
            'harga_jual' => "required|min:0|numeric",
            'satuan' => "required|string|max:20",
            "image" => "required|image|file|max:5120",
        ]);

        Drug::create(array_merge($validatedData, [
            "image" => $request->file('image')->store("drug-images"),
        ]));

        return redirect()
            ->route('admin.drugs.index')
            ->with('success', 'Data Produk Obat baru berhasil ditambahkan.');
    }

    public function show(Drug $drug)
    {
        return view('drugs.show', [
            "title" => "Detail Data Produk Obat",
            "drug" => $drug
        ]);
    }

    public function edit(Drug $drug)
    {
        return view('drugs.edit', [
            "title" => "Edit Data Produk Obat",
            "drug" => $drug,
        ]);
    }

    public function update(Request $request, Drug $drug)
    {
        $uniqueValidation = $request->kode_obat === $drug->kode_obat ? '' : '|unique:drugs';

        $validatedData = $request->validate([
            'kode_obat' => "required|min:5|max:5" . $uniqueValidation,
            'nama_obat' => "required",
            'stock' => 'required|min:0|numeric',
            'harga_beli' => "required|min:0|numeric",
            'harga_jual' => "required|min:0|numeric",
            'satuan' => "required|string|max:20",
            "image" => "sometimes|required|image|file|max:5120|nullable",
        ]);

        $drug->update(array_merge($validatedData, [
            "image" => $this->uploadOrReturnDefault("image", $drug->image, 'drug-images'),
        ]));

        return redirect()->route('admin.drugs.index')->with('success', 'Data Produk Obat berhasil diubah.');
    }

    public function destroy(Drug $drug)
    {
        Storage::delete($drug->image);
        $drug->delete();
        return redirect()->route('admin.drugs.index')->with('success', 'Data Produk Obat berhasil dihapus.');
    }
}
