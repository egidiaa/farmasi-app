<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function index()
    {
        return view('users.index', [
            "title" => "Data Produk User Admin",
            "users" => User::filters(request(['q']))->paginate(5)->withQueryString()
        ]);
    }

    public function create()
    {
        return view('users.create', [
            "title" => "Tambah Data Produk User Admin Baru",
        ]);
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'name' => "required",
            'email' => "required|email|unique:users",
            "password" => "required|min:5|confirmed",
            "alamat" => "max:300",
            "no_telp" => "max:15",
        ]);

        User::create([
            'role' => 'admin',
            'name' => $validatedData['name'],
            'email' => $validatedData['email'],
            'alamat' => $validatedData['alamat'],
            'no_telp' => $validatedData['no_telp'],
            'password' => Hash::make($validatedData['password']),
        ]);

        return redirect()
            ->route('admin.users.index')
            ->with('success', 'Data Produk User Admin baru berhasil ditambahkan.');
    }

    public function show(User $user)
    {
        return view('users.show', [
            "title" => "Detail Data Produk User Admin",
            "user" => $user
        ]);
    }

    public function edit(User $user)
    {
        return view('users.edit', [
            "title" => "Edit Data Produk User Admin",
            "user" => $user,
        ]);
    }

    public function update(Request $request, User $user)
    {
        $uniqueValidation = $request->email === $user->email ? '' : '|unique:users';

        $validatedData = $request->validate([
            'name' => "required",
            'email' => "required|email" . $uniqueValidation,
            "alamat" => "max:300",
            "no_telp" => "max:15",
        ]);

        $user->update($validatedData);

        return redirect()->route('admin.users.index')->with('success', 'Data Produk User Admin berhasil diubah.');
    }

    public function destroy(User $user)
    {
        $user->delete();
        return redirect()->route('admin.users.index')->with('success', 'Data Produk User Admin berhasil dihapus.');
    }
}
