<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Drug extends Model
{
    use HasFactory;

    protected $guarded = ['id'];

    public function scopeFilters(Builder $query, array $filters)
    {
        $query->when($filters['q'] ?? null, function (Builder $query, $search) {
            $query
                ->where('nama_obat', 'LIKE', "%" . $search . "%")
                ->orWhere('kode_obat', 'LIKE', "%" . $search . "%")
                ->orWhere('satuan', 'LIKE', "%" . $search . "%")
                ->orWhere('stock', 'LIKE', "%" . $search . "%")
                ->orWhere('harga_jual', 'LIKE', "%" . $search . "%")
                ->orWhere('harga_beli', 'LIKE', "%" . $search . "%");
        });
    }
}
