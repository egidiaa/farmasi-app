<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('riwayat_pesanans', function (Blueprint $table) {
            $table->id();
            // saya saranin pakai foreign key
            $table->foreignId('user_id')->constrained();
            $table->foreignId('drug_id')->constrained();
            // atau kalau tetap pengen pakai namanya saja
            // $table->string('nama_pelanggan');
            // $table->string('nama_obat');
            $table->decimal('total_harga', 20, 2);
            $table->dateTime('tgl_pesan');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('riwayat_pesanans');
    }
};
