const showPreviewImage = (event, idImgTagPreview) => {
    const reader = new FileReader();
    const imgElement = document.querySelector(idImgTagPreview);

    reader.onload = function () {
        if (reader.readyState == 2) {
            imgElement.src = reader.result;
        }
    };

    reader.readAsDataURL(event.target.files[0]);
};

window.showPreviewImage = showPreviewImage;
