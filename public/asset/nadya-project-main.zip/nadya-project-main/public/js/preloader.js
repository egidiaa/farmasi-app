const preloader = document.querySelector(".pre-loader");

document.addEventListener("DOMContentLoaded", () => {
    preloader.classList.add("hide");
    // 300 === main.css transition duration
    setTimeout(() => {
        preloader.classList.replace("d-flex", "d-none");
    }, 300);
});

window.onbeforeunload = function (e) {
    preloader.classList.remove("hide");
    preloader.classList.replace("d-none", "d-flex");
};

// when user click back/previous page
window.addEventListener(
    "popstate",
    function (event) {
        preloader.classList.add("hide");
        preloader.classList.replace("d-flex", "d-none");
    },
    false
);
