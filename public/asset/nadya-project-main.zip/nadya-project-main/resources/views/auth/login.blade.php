@extends('layouts.auth')

@push('style')
<link rel="stylesheet" href="{{ asset('css/auth/login.css') }}">
@endpush

@section('content')

<div class="w-100">

    <main class="form-signin w-100 m-auto">
        <form method="POST" action="{{ route('login') }}" id="login-form">
            @csrf

            <h1 class="h3 mb-3 fw-normal">Silahkan Masuk</h1>

            @include('partials.validation-alerts')

            <div class="form-floating">
                <input type="email" class="form-control first" id="floatingInputEmail" name="email"
                    placeholder="name@example.com" autofocus>
                <label for="floatingInputEmail">Email address</label>
            </div>
            <div class="form-floating">
                <input type="password" class="form-control last" id="floatingPassword" name="password"
                    placeholder="Password">
                <label for="floatingPassword">Password</label>
            </div>

            <div class="form-check mb-3">
                <input class="form-check-input" type="checkbox" name="remember" id="flexCheckRemember">
                <label class="form-check-label" for="flexCheckRemember">
                    Ingatkan Saya di Perangkat ini
                </label>
            </div>

            <button class="w-100 btn btn-primary" type="submit" id="login-form-button">Masuk</button>

            <a href="{{ route('register') }}" class="mt-3 d-block">Daftar disini!</a>

            <p class="mt-5 mb-3 text-muted">&copy; 2022</p>
        </form>
    </main>

</div>
@endsection