@extends('layouts.auth')

@push('style')
<link rel="stylesheet" href="{{ asset('css/auth/login.css') }}">
@endpush

@section('content')

<div class="w-100 py-5" style="height: 800px;">
    <main class="form-signin w-100 mx-auto">

        <form method="POST" action="{{ route('register') }}" id="login-form" class="mt-5">
            @csrf

            <h1 class="h3 mb-3 fw-normal">Registrasi</h1>

            @include('partials.validation-alerts')

            <div class="form-floating">
                <input type="text" class="form-control first" id="floatingInputName" name="name"
                    value="{{ old('name') }}" placeholder="name@example.com" autofocus>
                <label for="floatingInputName">Nama</label>
            </div>
            <div class="form-floating">
                <input type="email" class="form-control middle" id="floatingInputEmail" name="email"
                    value="{{ old('email') }}" placeholder="name@example.com">
                <label for="floatingInputEmail">Email address</label>
            </div>
            <div class="form-floating">
                <input type="tel" class="form-control middle" id="floatingInputNoTelp" name="no_telp"
                    value="{{ old('no_telp') }}" placeholder="name@example.com">
                <label for="floatingInputNoTelp">Nomor Telepon</label>
            </div>
            <div class="form-floating">
                <textarea class="form-control middle" placeholder="Masukan alamat anda disini" id="floatingTextarea2"
                    style="height: 100px" name="alamat">{{ old('alamat') }}</textarea>
                <label for="floatingTextarea2">Alamat</label>
            </div>
            <div class="form-floating">
                <input type="password" class="form-control middle" id="floatingPassword" name="password"
                    placeholder="Password">
                <label for="floatingPassword">Password</label>
            </div>
            <div class="form-floating">
                <input type="password" class="form-control last" id="floatingPasswordConfirmation"
                    name="password_confirmation" placeholder="Password Confirmation">
                <label for="floatingPasswordConfirmation">Ulangi Password</label>
            </div>

            <button class="w-100 btn btn-primary" type="submit" id="login-form-button">Register</button>

            <a href="{{ route('login') }}" class="mt-3 d-block">Login disini!</a>

            <p class="mt-5 mb-3 text-muted">&copy; 2022</p>
        </form>
    </main>

</div>
@endsection