{{--
<link rel="stylesheet" href="{{ asset('tom-select/tom-select.bootstrap5.min.css') }}"> --}}

{{-- Bootstrap 5.2 CSS --}}
<link rel="stylesheet" href="{{ asset('bootstrap5/css/bootstrap.min.css') }}">

{{-- Flatpickr CSS --}}
{{--
<link rel="stylesheet" href="{{ asset('flatpickr/flatpickr.min.css') }}"> --}}

<!----===== Boxicons CSS ===== -->
{{--
<link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'> --}}
{{-- Main CSS --}}

<link rel="stylesheet" href="{{ asset('css/main.css') }}">