<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse pb-5">
    <div class="position-sticky pt-3">
        <ul class="nav flex-column">
            <h6 class="sidebar-heading px-3 mt-4 mb-2 text-muted text-uppercase fw-bold">
                <span>Menu Utama</span>
            </h6>
            <li class="nav-item">
                <a class="nav-link {{ request()->routeIs('admin.dashboard.*') ? 'active fw-bold' : '' }}"
                    aria-current="page" href="{{ route('admin.dashboard.index') }}">
                    <span data-feather="home" class="align-text-middle"></span>
                    Dashboard
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link {{ request()->routeIs('admin.drugs.*') ? 'active fw-bold' : '' }}"
                    aria-current="page" href="{{ route('admin.drugs.index') }}">
                    <span data-feather="home" class="align-text-middle"></span>
                    Obat
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link {{ request()->routeIs('admin.pelanggan.*') ? 'active fw-bold' : '' }}"
                    aria-current="page" href="{{ route('admin.pelanggan.index') }}">
                    <span data-feather="home" class="align-text-middle"></span>
                    Pelanggan
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link {{ request()->routeIs('admin.users.*') ? 'active fw-bold' : '' }}"
                    aria-current="page" href="{{ route('admin.users.index') }}">
                    <span data-feather="home" class="align-text-middle"></span>
                    Users / Admin
                </a>
            </li>

            <hr>

            {{-- <form action="{{ route('auth.logout') }}" method="post"
                onsubmit="return confirm('Apakah anda yakin ingin keluar?')">
                @method('DELETE')
                @csrf
                <button
                    class="nav-link btn btn-danger w-full mt-4 d-block bg-transparent border-0 fw-bold text-danger px-3">
                    <span data-feather="log-out" class="align-text-middle text-danger"></span>
                    Keluar
                </button>
            </form> --}}
            <div class="px-3">
                <button type="button" class="fw-bold btn btn-danger w-100" data-bs-toggle="modal"
                    data-bs-target="#exampleModal">
                    Keluar
                </button>
            </div>
    </div>
</nav>

<!-- Button trigger modal -->

<!-- Modal -->
<div class="modal fade" id="exampleModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
    aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Konfirmasi</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="{{ route('logout') }}" method="post">
                @method('DELETE')
                @csrf
                <div class="modal-body">
                    <p class="text-danger py-2 m-0">Apakah anda yakin ingin keluar ?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-dark" data-bs-dismiss="modal">Batal</button>
                    <button class="btn btn-danger fw-bold">
                        <span data-feather="log-out" class="align-text-middle"></span>
                        Keluar
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>