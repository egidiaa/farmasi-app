@extends('layouts.app')

@section('content')
<div class="row">
    <div class="col-md-8">
        <div class="card shadow">
            <div class="card-header">
                Form {{ $title }}
            </div>
            <form action="{{ route('admin.users.store') }}" method="post" novalidate>
                @csrf

                <div class="card-body py-4">
                    <div class="row">
                        <div class="mb-3">
                            <x-forms.label id="name">Nama</x-forms.label>
                            <x-forms.input name="name" :value="old('name')" autofocus />
                        </div>

                        <div class="mb-3">
                            <x-forms.label id="email">Email</x-forms.label>
                            <x-forms.input type="email" name="email" :value="old('email')" />
                        </div>

                        <div class="mb-3">
                            <x-forms.label id="no_telp" :required="false">No. Telepon</x-forms.label>
                            <x-forms.input name="no_telp" type="tel" :value="old('no_telp')" />
                        </div>

                        <div class="mb-3">
                            <x-forms.label id="alamat" :required="false">Alamat</x-forms.label>
                            <x-forms.textarea name="alamat">{{ old('alamat') }}</x-forms.textarea>
                        </div>

                        <div class="mb-3">
                            <x-forms.label id="password">Password</x-forms.label>
                            <x-forms.input name="password" type="password" />
                        </div>
                        <div class="mb-3">
                            <x-forms.label id="password_confirmation">Ulangi Password</x-forms.label>
                            <x-forms.input name="password_confirmation" type="password" />
                        </div>

                    </div>
                </div>

                <div class="card-footer d-flex justify-content-between flex-column-reverse gap-2 flex-md-row py-3">
                    <div class="d-grid d-md-block gap-2">
                        <a href="{{ route('admin.users.index') }}" class="btn btn-danger font-weight-bold">
                            <span data-feather="arrow-left" class="align-text-middle me-1"></span>
                            Batal</a>
                        <button type="reset" class="btn btn-warning">
                            <span data-feather="refresh-cw" class="align-text-middle me-1"></span>
                            Reset
                        </button>
                    </div>
                    <div class="d-grid d-md-block gap-2">
                        <button type="submit" class="btn btn-primary">
                            <span data-feather="save" class="align-text-middle me-1"></span>
                            Simpan
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection