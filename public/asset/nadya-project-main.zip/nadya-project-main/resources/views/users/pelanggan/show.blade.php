@extends('layouts.app')

@section('content')
<div class="row">
    <div class="col-md-7">
        <div class="card shadow mb-2">
            <div class="card-header">Detail Data Lengkap Pelanggan</div>
            <div class="card-body py-4">
                <dl class="row" style="line-height: 27px;">
                    <dt class="col-sm-4">Nama</dt>
                    <dd class="col-sm-8">{{ $user->name }}</dd>
                    <dt class="col-sm-4">Email</dt>
                    <dd class="col-sm-8">
                        <a href="mailto:{{ $user->email }}" class="badge text-bg-success" style="font-size: .9em;">
                            {{ $user->email }}
                        </a>
                    </dd>
                    <dt class="col-sm-4">No. Telepon</dt>
                    <dd class="col-sm-8">
                        <a href="tel:{{ $user->no_telp }}" class="badge text-bg-success" style="font-size: .9em;">
                            {{ $user->no_telp }}
                        </a>
                    </dd>
                    <dt class="col-sm-4">Alamat</dt>
                    <dd class="col-sm-8">{!! nl2br($user->alamat) !!}</dd>
                    <dt class="col-sm-4">Dibuat Pada</dt>
                    <dd class="col-sm-8">{{ $user->created_at->diffForHumans() }} ({{
                        $user->created_at->format('d/m/y
                        H:i') }})</dd>
                    <dt class="col-sm-4">Diubah Pada</dt>
                    <dd class="col-sm-8">{{ $user->updated_at->diffForHumans() }} ({{
                        $user->updated_at->format('d/m/y
                        H:i') }})</dd>
                </dl>
            </div>

            <div class="card-footer d-flex justify-content-end">
                <div class="btn-group">
                    <a href="{{ route('admin.users.index') }}" class="btn btn-danger font-weight-bold">
                        <span data-feather="arrow-left" class="align-text-middle me-1"></span>
                        Batal</a>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection