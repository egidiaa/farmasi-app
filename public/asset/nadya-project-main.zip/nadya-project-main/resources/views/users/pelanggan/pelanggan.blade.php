@extends('layouts.app')

@section('buttons')
<div class="btn-toolbar mb-2 mb-md-0">

</div>
@endsection

@section('content')

<div class="my-3">
    <form action="" method="get">
        <label for="q" class="form-label">Cari</label>
        <input type="text" class="form-control" id="q" name="q" value="{{ request('q') }}">
    </form>
</div>

<div class="table-responsive">
    <table class="table table-striped table-bordered table-sm">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nama Lengkap</th>
                <th scope="col">Email</th>
                <th scope="col">Nomor Telepon</th>
                <th scope="col"></th>
            </tr>
        </thead>
        <tbody>
            @foreach ($users as $user)
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $user->name }}</td>
                <td>
                    <a href="mailto:{{ $user->email }}" class="badge text-bg-success">{{ $user->email }}</a>
                </td>
                <td>
                    <a href="tel:{{ $user->no_telp }}" class="badge text-bg-success">{{ $user->no_telp }}</a>
                </td>
                <td>
                    <div class="d-block">
                        {{-- <a href="{{ route('admin.users.edit', $user->id) }}" class="badge text-bg-info">Edit</a>
                        --}}
                        <a href="{{ route('admin.pelanggan.show', $user->id) }}" class="badge text-bg-dark">Detail</a>
                        <form action="{{ route('admin.users.destroy', $user->id) }}" method="post"
                            class="d-inline-block">
                            @csrf
                            @method('DELETE')
                            <button class="badge text-bg-danger border-0">Hapus</button>
                        </form>
                    </div>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    <div class="py-3">
        {{ $users->links() }}
    </div>
</div>
@endsection