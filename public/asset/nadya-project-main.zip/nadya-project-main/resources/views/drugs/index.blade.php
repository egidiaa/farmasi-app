@extends('layouts.app')

@section('buttons')
<div class="btn-toolbar mb-2 mb-md-0">
    <div>
        <a href="{{ route('admin.drugs.create') }}" class="btn btn-primary">
            <span data-feather="plus" class="align-text-middle me-1"></span>
            Tambah Produk Obat
        </a>
    </div>
</div>
@endsection

@section('content')

<div class="my-3">
    <form action="" method="get">
        <label for="q" class="form-label">Cari</label>
        <input type="text" class="form-control" id="q" name="q" value="{{ request('q') }}">
    </form>
</div>

<div class="table-responsive">
    <table class="table table-striped table-bordered table-sm">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Gambar</th>
                <th scope="col">Kode</th>
                <th scope="col">Nama</th>
                <th scope="col">Stock</th>
                <th scope="col">Harga Beli/Harga Jual</th>
                <th scope="col">Satuan</th>
                <th scope="col"></th>
            </tr>
        </thead>
        <tbody>
            @foreach ($drugs as $drug)
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>
                    <img src="{{ asset('storage/' . $drug->image) }}" alt="" width="100" class="img-thumbnail">
                </td>
                <td>{{ $drug->kode_obat }}</td>
                <td>{{ $drug->nama_obat }}</td>
                <td>{{ $drug->stock }}</td>
                <td>
                    <span class="badge text-bg-primary">Rp. {{ number_format($drug->harga_beli, 2,',','.') }}</span>
                    <span class="fw-bold">/</span>
                    <span class="badge text-bg-primary">Rp. {{
                        number_format($drug->harga_jual, 2,',','.') }}</span>
                </td>
                <td><span class="badge text-bg-primary fw-bold">{{ $drug->satuan }}</span></td>
                <td>
                    <div class="d-block">
                        <a href="{{ route('admin.drugs.edit', $drug->id) }}" class="badge text-bg-info">Edit</a>
                        <a href="{{ route('admin.drugs.show', $drug->id) }}" class="badge text-bg-dark">Detail</a>
                        <form action="{{ route('admin.drugs.destroy', $drug->id) }}" method="post"
                            class="d-inline-block">
                            @csrf
                            @method('DELETE')
                            <button class="badge text-bg-danger border-0">Hapus</button>
                        </form>
                    </div>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    <div class="py-3">
        {{ $drugs->links() }}
    </div>
</div>
@endsection