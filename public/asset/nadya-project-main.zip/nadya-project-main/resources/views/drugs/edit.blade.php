@extends('layouts.app')

@section('content')
<div class="row">
    <div class="col-md-8">
        <div class="card shadow">
            <div class="card-header">
                Form {{ $title }}
            </div>
            <form action="{{ route('admin.drugs.update', $drug) }}" method="post" novalidate
                enctype="multipart/form-data">
                @csrf
                @method('put')

                <div class="card-body py-4">
                    <div class="row">
                        <div class="mb-3">
                            <x-forms.label id="kode_obat">Kode Obat</x-forms.label>
                            <x-forms.input name="kode_obat" :value="old('kode_obat', $drug->kode_obat)" autofocus
                                maxlength="5" placeholder="KO001" />
                        </div>

                        <div class="mb-3">
                            <x-forms.label id="nama_obat">Nama Obat</x-forms.label>
                            <x-forms.input name="nama_obat" :value="old('nama_obat', $drug->nama_obat)" />
                        </div>

                        <div class="mb-3">
                            <div class="row">
                                <div class="col-sm-12 col-md-4 mb-2 md-md-0">
                                    <div class="bg-light border rounded overflow-hidden d-grid"
                                        style="min-height: 50px; height: 100%; place-content: center;">
                                        {{-- <span data-feather="slash"></span> --}}
                                        <img src="{{ asset('storage/'.$drug->image) }}" alt=""
                                            class="bg-gray w-100 d-block" id="img-preview">
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-8">
                                    <x-forms.label id="image" :required="false">Foto Anggota</x-forms.label>
                                    <x-forms.input type="file" name="image"
                                        onchange="showPreviewImage(event, '#img-preview')" />
                                </div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <x-forms.label id="harga_beli">Harga Beli</x-forms.label>
                            <x-forms.input type="number" name="harga_beli"
                                :value="old('harga_beli', intval($drug->harga_beli))" />
                        </div>

                        <div class="mb-3">
                            <x-forms.label id="harga_jual">Harga Jual</x-forms.label>
                            <x-forms.input type="number" name="harga_jual"
                                :value="old('harga_jual', intval($drug->harga_jual))" />
                        </div>

                        <div class="mb-3">
                            <x-forms.label id="stock">Stok</x-forms.label>
                            <x-forms.input type="number" name="stock" :value="old('stock', $drug->stock)" />
                        </div>

                        <div class="mb-3">
                            <x-forms.label id="satuan">Satuan</x-forms.label>
                            <x-forms.input name="satuan" :value="old('satuan', $drug->satuan)" />
                        </div>
                    </div>
                </div>

                <div class="card-footer d-flex justify-content-between flex-column-reverse gap-2 flex-md-row py-3">
                    <div class="d-grid d-md-block gap-2">
                        <a href="{{ route('admin.drugs.index') }}" class="btn btn-danger font-weight-bold">
                            <span data-feather="arrow-left" class="align-text-middle me-1"></span>
                            Batal</a>
                    </div>
                    <div class="d-grid d-md-block gap-2">
                        <button type="submit" class="btn btn-primary">
                            <span data-feather="save" class="align-text-middle me-1"></span>
                            Simpan
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection