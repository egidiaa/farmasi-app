@extends('layouts.app')

@section('content')
<div class="row">
    <div class="col-md-7">
        <div class="card shadow mb-2">
            <div class="card-header">Detail Data Lengkap Obat</div>
            <div class="card-body py-4">
                <dl class="row" style="line-height: 27px;">
                    <dt class="col-sm-4">Kode Obat</dt>
                    <dd class="col-sm-8">
                        <span class="badge text-bg-info fw-bold">{{ $drug->kode_obat }}</span>
                    </dd>
                    <dt class="col-sm-4">Nama Obat</dt>
                    <dd class="col-sm-8">{{ $drug->nama_obat }}</dd>
                    <dt class="col-sm-4">Stock</dt>
                    <dd class="col-sm-8">{{ $drug->stock }}</dd>
                    <dt class="col-sm-4">Harga Beli</dt>
                    <dd class="col-sm-8">
                        <span class="badge text-bg-primary">Rp. {{ number_format($drug->harga_beli, 2,',','.') }}</span>
                    </dd>
                    <dt class="col-sm-4">Harga Jual</dt>
                    <dd class="col-sm-8">
                        <span class="badge text-bg-primary">Rp. {{
                            number_format($drug->harga_jual, 2,',','.') }}</span>
                    </dd>
                    <dt class="col-sm-4">Satuan</dt>
                    <dd class="col-sm-8">
                        <span class="badge text-bg-primary fw-bold">{{ $drug->satuan }}</span>
                    </dd>
                    <dt class="col-sm-4">Dibuat Pada</dt>
                    <dd class="col-sm-8">{{ $drug->created_at->diffForHumans() }} ({{
                        $drug->created_at->format('d/m/y
                        H:i') }})</dd>
                    <dt class="col-sm-4">Diubah Pada</dt>
                    <dd class="col-sm-8">{{ $drug->updated_at->diffForHumans() }} ({{
                        $drug->updated_at->format('d/m/y
                        H:i') }})</dd>
                </dl>
            </div>

            <div class="card-footer d-flex justify-content-end">
                <div class="btn-group">
                    <a href="{{ route('admin.drugs.index') }}" class="btn btn-danger font-weight-bold">
                        <span data-feather="arrow-left" class="align-text-middle me-1"></span>
                        Batal</a>

                    <a href="{{ route('admin.drugs.edit', $drug->id) }}" class="btn btn-primary">
                        <span data-feather="edit-3" class="align-text-middle me-1"></span>
                        Edit
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-5">
        <div class="card shadow">
            <div class="card-header">
                Foto Obat
            </div>
            <div class="card-body">
                @if ($drug->image)
                <img src="{{ asset('storage/' . $drug->image) }}" alt="Foto {{ $drug->nama_obat }}"
                    class="img-thumbnail w-100">
                @else
                <p class="text-danger text-center py-5">Tidak Ada Foto</p>
                @endif
            </div>
        </div>
    </div>
</div>
@endsection