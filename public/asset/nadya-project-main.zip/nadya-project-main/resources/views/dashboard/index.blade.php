@extends('layouts.app')

@section('content')
<div>
    <div class="row mb-4">
        <div class="col-12">
            <div class="card shadow-lg">
                <div class="card-body p-4 d-flex align-items-center justify-content-between">
                    <div>
                        <h1 class="fs-3 mb-2">Apa Kabar, <span class="fw-semibold">{{
                                auth()->user()->name
                                }}?</span></h1>
                        <h4 class="fs-5 text-muted mb-4">{{ now()->format('F d, Y') }}</h4>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection